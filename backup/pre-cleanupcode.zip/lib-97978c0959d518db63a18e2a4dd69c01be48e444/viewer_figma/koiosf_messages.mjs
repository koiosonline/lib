import {sleep,subscribe,publish,getElement} from '../lib/koiosf_util.mjs'; 
import {SwitchPage} from '../genhtml/startgen.mjs';

export async function DisplayMessage(text) {    

    console.log("In DisplayMessage");
     getElement("ov_message").dispatchEvent(new CustomEvent("show"));  
    
   // var msg=getElement("message");
    var msgtext=getElement("msg-text");
    //console.log(msg);
    msgtext.innerText=text;
    
   // msg.style.display="flex";
    await sleep(3000);
   // msg.style.display="none";    
   getElement("ov_message").dispatchEvent(new CustomEvent("hide"));  
   //SwitchPage("close") // close message overlay
}

export async function SwitchDisplayMessageContinous(fOn) {
    console.log("In InitDisplayMessageContinous");
  
  
  getElement("ov_message").dispatchEvent(new CustomEvent(fOn?"show":"hide"));  
  
    if (!fOn) 
      SwitchPage("close") // close message overlay
    
    var msgtext=getElement("msg-text");
    msgtext.innerText = "";
    
}


export async function DisplayMessageContinous(text) {    
    //console.log("In DisplayMessageContinous");
   // var msg=getElement("message");
    var msgtext=getElement("msg-text");
    //console.log(msg);
    msgtext.innerText +=text+"\n";
    msgtext.scrollTop = msgtext.scrollHeight; // keep the windows "scrolled down"
    
}

 
