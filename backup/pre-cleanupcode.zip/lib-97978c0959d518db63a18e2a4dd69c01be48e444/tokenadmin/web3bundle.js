Web3Modal = require("web3modal");
WalletConnectProvider = require("@walletconnect/web3-provider").default;
Web3 = require("web3");